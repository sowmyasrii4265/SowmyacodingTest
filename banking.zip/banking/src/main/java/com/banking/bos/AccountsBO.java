package com.banking.bos;

import com.banking.modal.Customer;

public class AccountsBO {

	private Double balance;
    private String type;  


    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    private Customer customer;


	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
    
    
}
