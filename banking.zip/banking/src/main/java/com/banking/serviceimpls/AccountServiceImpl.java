package com.banking.serviceimpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.bos.AccountsBO;
import com.banking.modal.Account;
import com.banking.repos.AccountRepo;
import com.banking.repos.CustomerRepo;
import com.banking.services.AccountService;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepo accountRepository;

	@Autowired
	private CustomerRepo customerRepo;

	
	@Override
	@Transactional
	public Account createAccount(AccountsBO account) {
		Account accountRepoObj = new Account(account.getType(), account.getBalance(),customerRepo.save(account.getCustomer()));
		return accountRepository.save(accountRepoObj);
	}

	@Override
	@Transactional
	public Account getAccountById(Long id) {
		return accountRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}

	@Override
	@Transactional
	public Account updateAccount(Long id, Account account) {
		if (accountRepository.existsById(id)) {
			account.setId(id);
			return accountRepository.save(account);
		}
		return null;
	}

	@Override
	@Transactional
	public void deleteAccount(Long id) {
		accountRepository.deleteById(id);
	}

	@Override
	@Transactional
	public Account depositMoney(Long id, Double amount) {
		Optional<Account> optionalAccount = accountRepository.findById(id);
		if (optionalAccount.isPresent()) {
			Account account = optionalAccount.get();
			account.setBalance(account.getBalance() + amount);
			return accountRepository.save(account);
		}
		return null;
	}

	@Override
	@Transactional
	public Account withdrawMoney(Long id, Double amount) {
		Optional<Account> optionalAccount = accountRepository.findById(id);
		if (optionalAccount.isPresent()) {
			Account account = optionalAccount.get();
			if (account.getBalance() >= amount) {
				account.setBalance(account.getBalance() - amount);
				return accountRepository.save(account);
			}
		}
		return null;
	}

	@Override
	@Transactional
	public Account transferMoney(Long sourceId, Long targetId, Double amount) {
		Account sourceAccount = getAccountById(sourceId);
		Account targetAccount = getAccountById(targetId);

		if (sourceAccount != null && targetAccount != null && sourceAccount.getBalance() >= amount) {
			sourceAccount.setBalance(sourceAccount.getBalance() - amount);
			targetAccount.setBalance(targetAccount.getBalance() + amount);

			accountRepository.save(sourceAccount);
			accountRepository.save(targetAccount);

			return sourceAccount; // returning the source account after transfer
		}
		return null;
	}

}
