package com.banking.serviceimpls;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.modal.Customer;
import com.banking.repos.CustomerRepo;
import com.banking.services.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{

	 @Autowired
	    private CustomerRepo customerRepository;

	    @Override
	    public Customer createCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }

	    @Override
		@Transactional
	    public Customer getCustomerById(Long id) {
	        return customerRepository.findById(id).orElse(null);
	    }

	    @Override
		@Transactional
	    public List<Customer> getAllCustomers() {
	        return customerRepository.findAll();
	    }

	    @Override
		@Transactional
	    public Customer updateCustomer(Long id, Customer customer) {
	        if (customerRepository.existsById(id)) {
	            customer.setId(id);
	            return customerRepository.save(customer);
	        }
	        return null;
	    }

	    @Override
		@Transactional
	    public void deleteCustomer(Long id) {
	        customerRepository.deleteById(id);
	    }
}
