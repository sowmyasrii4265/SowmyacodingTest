package com.banking.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banking.modal.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Long>{

	  // Custom method to find a customer by email
    Optional<Customer> findByEmail(String email);

    // Custom method to find customers by name (might return multiple customers with the same name)
    List<Customer> findByName(String name);
}
