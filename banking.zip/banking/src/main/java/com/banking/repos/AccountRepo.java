package com.banking.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.banking.modal.Account;

public interface AccountRepo extends JpaRepository<Account, Long> {

    // Custom method to find accounts of a specific customer
    List<Account> findByCustomerId(Long customerId);

    // Custom method to find accounts with balance greater than a specific amount
    List<Account> findByBalanceGreaterThan(Double balance);
}