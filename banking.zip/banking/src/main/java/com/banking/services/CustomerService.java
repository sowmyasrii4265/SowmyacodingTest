package com.banking.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.modal.Customer;

@Service
public interface CustomerService {

	Customer createCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer getCustomerById(Long id);

	Customer updateCustomer(Long id, Customer customer);

	void deleteCustomer(Long id);

}
