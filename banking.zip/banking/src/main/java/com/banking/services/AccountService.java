package com.banking.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.bos.AccountsBO;
import com.banking.modal.Account;

@Service
public interface AccountService {

	Account createAccount(AccountsBO account);

	Account getAccountById(Long id);

	List<Account> getAllAccounts();

	Account updateAccount(Long id, Account account);

	void deleteAccount(Long id);

	Account depositMoney(Long id, Double amount);

	Account withdrawMoney(Long id, Double amount);

	Account transferMoney(Long sourceId, Long targetId, Double amount);
	

}
