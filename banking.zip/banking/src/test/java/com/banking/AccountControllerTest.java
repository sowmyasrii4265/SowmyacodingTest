package com.banking;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.banking.bos.AccountsBO;
import com.banking.controllers.AccountController;
import com.banking.modal.Account;
import com.banking.services.AccountService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@WebMvcTest(AccountController.class)
public class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AccountService accountService;

    @Autowired
    ObjectMapper objectMapper;

    @Before
    public void setUp() throws Exception {
        // Optionally initialize mocks or set default behavior
    }

    @Test
    public void testCreateAccount() throws Exception {
        AccountsBO mockBO = new AccountsBO(); // Set fields as needed
        Account mockAccount = new Account(); // Set fields as needed

        when(accountService.createAccount(any(AccountsBO.class))).thenReturn(mockAccount);

        mockMvc.perform(post("/api/accounts/")
                .content(objectMapper.writeValueAsString(mockBO))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(mockAccount)));
    }

    // Similarly, you would write tests for other endpoints
}
